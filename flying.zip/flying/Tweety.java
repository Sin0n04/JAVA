package flying;

public class Tweety extends Canary {
	int movieappearance;
	
	Tweety(int a, char s, double size, int mo){
		super(s,a,size);
		this.movieappearance = mo;
	}
	
	
	public static void main(String[] args) {
		
	}
	

}
